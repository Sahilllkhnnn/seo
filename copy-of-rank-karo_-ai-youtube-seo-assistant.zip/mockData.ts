
import type { AnalyticsData } from './types';

export const mockAnalyticsData: AnalyticsData = {
    summary: {
        views: 248395,
        watchTime: 12450,
        subscribers: 7340,
        ctr: 6.8,
    },
    performance: [
        { date: 'Day 1', views: 3000 },
        { date: 'Day 2', views: 4500 },
        { date: 'Day 3', views: 6200 },
        { date: 'Day 4', views: 5100 },
        { date: 'Day 5', views: 7800 },
        { date: 'Day 6', views: 9200 },
        { date: 'Day 7', views: 11500 },
    ],
    topVideos: [
        {
            rank: 1,
            thumbnailUrl: 'https://picsum.photos/seed/video1/120/90',
            title: 'Ultimate Guide to Drone Cinematography',
            views: 102345,
            watchTime: 6123,
        },
        {
            rank: 2,
            thumbnailUrl: 'https://picsum.photos/seed/video2/120/90',
            title: '10 Mistakes Beginner YouTubers Make',
            views: 56789,
            watchTime: 2345,
        },
        {
            rank: 3,
            thumbnailUrl: 'https://picsum.photos/seed/video3/120/90',
            title: 'Reviewing the new "CreatorPro" Camera',
            views: 34567,
            watchTime: 1890,
        },
        {
            rank: 4,
            thumbnailUrl: 'https://picsum.photos/seed/video4/120/90',
            title: 'How I Gained 1K Subscribers in 30 Days',
            views: 23456,
            watchTime: 1023,
        },
    ]
};
