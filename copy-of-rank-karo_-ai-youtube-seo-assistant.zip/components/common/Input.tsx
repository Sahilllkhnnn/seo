
import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {}

export const Input: React.FC<InputProps> = ({ className = '', ...props }) => {
    return (
        <input
            {...props}
            className={`block w-full px-4 py-2 rounded-lg border focus:outline-none focus:ring-2 focus:ring-teal-500 transition-colors ${className}`}
        />
    );
};
