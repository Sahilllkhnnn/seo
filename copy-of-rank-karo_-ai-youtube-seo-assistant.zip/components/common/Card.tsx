import React from 'react';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
    children: React.ReactNode;
    className?: string;
}

export const Card: React.FC<CardProps> = ({ children, className = '', ...props }) => {
    return (
        <div {...props} className={`bg-gray-800/50 p-4 md:p-6 rounded-lg border border-gray-700/50 shadow-lg ${className}`}>
            {children}
        </div>
    );
};