
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';
import { mockAnalyticsData } from '../mockData';
import type { AnalyticsData } from '../types';
import { Card } from './common/Card';
import { Button } from './common/Button';

interface AnalyticsProps {
    isChannelConnected: boolean;
    setChannelConnected: (connected: boolean) => void;
}

const Analytics: React.FC<AnalyticsProps> = ({ isChannelConnected, setChannelConnected }) => {

    if (!isChannelConnected) {
        return (
            <div className="h-full flex items-center justify-center p-4 md:p-6 text-gray-200">
                <Card className="text-center max-w-md">
                    <h2 className="text-2xl font-bold text-white mb-4">Connect Your YouTube Channel</h2>
                    <p className="text-gray-400 mb-6">
                        To access your video analytics, you need to connect your YouTube account. This will allow Rank Karo to securely fetch your performance data.
                    </p>
                    <Button onClick={() => setChannelConnected(true)} className="bg-blue-600 hover:bg-blue-700 w-full">
                        Connect YouTube Channel
                    </Button>
                </Card>
            </div>
        );
    }
    
    const data: AnalyticsData = mockAnalyticsData;

    return (
        <div className="h-full overflow-y-auto p-4 md:p-6 text-gray-200">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold text-white">Analytics Dashboard</h1>
                <Button onClick={() => setChannelConnected(false)} className="bg-red-600 hover:bg-red-700 text-sm">
                    Disconnect Channel
                </Button>
            </div>

            {/* KPIs */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                <KpiCard title="Total Views" value={data.summary.views.toLocaleString()} change="+12.5%" />
                <KpiCard title="Watch Time (hours)" value={data.summary.watchTime.toLocaleString()} change="+8.2%" />
                <KpiCard title="Subscribers" value={data.summary.subscribers.toLocaleString()} change="+251" />
                <KpiCard title="Click-Through Rate" value={`${data.summary.ctr}%`} change="-0.5%" isNegative={true} />
            </div>

            {/* Charts */}
            <div className="grid lg:grid-cols-2 gap-6 mb-6">
                <Card>
                    <h3 className="text-xl font-semibold text-white mb-4">Performance Over Time (Last 7 Days)</h3>
                    <ResponsiveContainer width="100%" height={300}>
                        <LineChart data={data.performance}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#4A5568" />
                            <XAxis dataKey="date" stroke="#A0AEC0" />
                            <YAxis stroke="#A0AEC0" />
                            <Tooltip contentStyle={{ backgroundColor: '#1A202C', border: '1px solid #2D3748' }} />
                            <Legend />
                            <Line type="monotone" dataKey="views" stroke="#4FD1C5" strokeWidth={2} activeDot={{ r: 8 }} />
                        </LineChart>
                    </ResponsiveContainer>
                </Card>
                <Card>
                    <h3 className="text-xl font-semibold text-white mb-4">Top Performing Videos</h3>
                     <div className="overflow-x-auto">
                        <table className="w-full text-left">
                            <tbody>
                                {data.topVideos.map(video => (
                                    <tr key={video.rank} className="border-b border-gray-700/50">
                                        <td className="p-3">
                                            <div className="flex items-center space-x-3">
                                                <img src={video.thumbnailUrl} alt={video.title} className="w-16 h-12 object-cover rounded-md"/>
                                                <span className="font-medium text-white truncate max-w-xs">{video.title}</span>
                                            </div>
                                        </td>
                                        <td className="p-3 text-right">{video.views.toLocaleString()} views</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </Card>
            </div>
        </div>
    );
};

const KpiCard: React.FC<{title: string, value: string, change: string, isNegative?: boolean}> = ({ title, value, change, isNegative }) => (
    <Card>
        <p className="text-gray-400 mb-1">{title}</p>
        <p className="text-3xl font-bold text-white mb-2">{value}</p>
        <p className={`text-sm ${isNegative ? 'text-red-400' : 'text-green-400'}`}>{change} vs. previous period</p>
    </Card>
);


export default Analytics;
