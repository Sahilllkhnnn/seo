import React, { useState, useCallback } from 'react';
import { generateContent } from '../services/geminiService';
import type { GeneratedContent } from '../types';
import { Card } from './common/Card';
import { Input } from './common/Input';
import { Button } from './common/Button';
import { Spinner } from './common/Spinner';

type ContentType = 'title' | 'description' | 'tags';

const CopyIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>;
const CheckIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>;

const ContentGenerator: React.FC = () => {
    const [topic, setTopic] = useState<string>('');
    const [keywords, setKeywords] = useState<string>('');
    const [generatedContent, setGeneratedContent] = useState<GeneratedContent[]>([]);
    const [loadingStates, setLoadingStates] = useState<Record<ContentType, boolean>>({
        title: false,
        description: false,
        tags: false,
    });
    const [error, setError] = useState<string | null>(null);
    const [copied, setCopied] = useState<string | null>(null);

    const handleCopy = (text: string[], type: string) => {
        const textToCopy = type === 'tags' ? text.join(', ') : text.join('\n\n');
        navigator.clipboard.writeText(textToCopy);
        setCopied(type);
        setTimeout(() => setCopied(null), 2000);
    };

    const handleGenerate = useCallback(async (type: ContentType) => {
        if (!topic) {
            setError('Please enter a topic to generate content.');
            return;
        }
        setError(null);
        setLoadingStates(prev => ({ ...prev, [type]: true }));
        try {
            const result = await generateContent(type, topic, keywords.split(',').map(k => k.trim()));
            setGeneratedContent(prev => {
                const existingIndex = prev.findIndex(item => item.type === type);
                if (existingIndex > -1) {
                    const newContent = [...prev];
                    newContent[existingIndex] = result;
                    return newContent;
                }
                return [...prev, result];
            });
        } catch (err) {
            setError(err instanceof Error ? err.message : `Failed to generate ${type}.`);
        } finally {
            setLoadingStates(prev => ({ ...prev, [type]: false }));
        }
    }, [topic, keywords]);
    
    const ResultCard: React.FC<{ type: ContentType, title: string }> = ({ type, title }) => {
        const content = generatedContent.find(c => c.type === type);
        const isLoading = loadingStates[type];

        return (
            <Card>
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-semibold text-white">{title}</h3>
                    <div className="flex items-center gap-2">
                        {content && (
                           <Button onClick={() => handleCopy(content.content, type)} className="bg-gray-700 hover:bg-gray-600 p-2">
                                {copied === type ? <CheckIcon/> : <CopyIcon/>}
                           </Button>
                        )}
                        <Button onClick={() => handleGenerate(type)} disabled={isLoading || !topic}>
                            {isLoading ? <Spinner /> : 'Generate'}
                        </Button>
                    </div>
                </div>
                <div className="bg-gray-900/50 p-4 rounded-lg min-h-[100px] text-gray-300">
                    {content ? (
                        <ul className={type === 'tags' ? 'flex flex-wrap gap-2' : 'space-y-3'}>
                            {content.content.map((item, index) => (
                                <li key={index} className={type === 'tags' ? 'bg-gray-700 text-teal-300 text-sm font-medium px-3 py-1 rounded-full' : 'whitespace-pre-wrap'}>
                                    {item}
                                </li>
                            ))}
                        </ul>
                    ) : <p>Click "Generate" to create {type}s.</p>}
                </div>
            </Card>
        );
    };

    return (
        <div className="h-full overflow-y-auto p-4 md:p-6 text-gray-200">
            <h1 className="text-3xl font-bold text-white mb-2">Content Generator</h1>
            <p className="text-gray-400 mb-6">Create SEO-optimized titles, descriptions, and tags in seconds.</p>

            <Card className="mb-6">
                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">Video Topic</label>
                        <Input
                            type="text"
                            placeholder="e.g., 'How to choose a mountain bike'"
                            value={topic}
                            onChange={(e) => setTopic(e.target.value)}
                            className="w-full bg-gray-700 border-gray-600 text-white"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">Primary Keywords (comma-separated)</label>
                        <Input
                            type="text"
                            placeholder="e.g., 'mountain bike, full suspension, hardtail'"
                            value={keywords}
                            onChange={(e) => setKeywords(e.target.value)}
                            className="w-full bg-gray-700 border-gray-600 text-white"
                        />
                    </div>
                </div>
                {error && <p className="mt-4 text-red-400 text-center">{error}</p>}
            </Card>
            
            <div className="space-y-6">
                <ResultCard type="title" title="Titles" />
                <ResultCard type="description" title="Descriptions" />
                <ResultCard type="tags" title="Tags" />
            </div>
        </div>
    );
};

export default ContentGenerator;