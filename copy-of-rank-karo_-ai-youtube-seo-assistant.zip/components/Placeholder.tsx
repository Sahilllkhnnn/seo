
import React from 'react';
import { Card } from './common/Card';

export const Placeholder: React.FC = () => {
    return (
        <div className="h-full flex items-center justify-center p-6">
            <Card className="text-center">
                <h2 className="text-2xl font-bold text-white mb-2">Coming Soon!</h2>
                <p className="text-gray-400">This feature is currently under development. Stay tuned for exciting updates!</p>
            </Card>
        </div>
    );
};
