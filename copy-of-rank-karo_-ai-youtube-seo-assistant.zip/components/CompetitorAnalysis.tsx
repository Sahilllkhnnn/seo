import React, { useState } from 'react';
import { analyzeCompetitorVideo } from '../services/geminiService';
import type { CompetitorAnalysisResult } from '../types';
import { Card } from './common/Card';
import { Input } from './common/Input';
import { Button } from './common/Button';
import { Spinner } from './common/Spinner';

const CopyIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>;
const CheckIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>;


const AnalysisResult: React.FC<{ analysis: CompetitorAnalysisResult }> = ({ analysis }) => {
    const [copied, setCopied] = useState<string | null>(null);

    const handleCopy = (text: string | string[], type: string) => {
        const textToCopy = Array.isArray(text) ? text.join(', ') : text;
        navigator.clipboard.writeText(textToCopy);
        setCopied(type);
        setTimeout(() => setCopied(null), 2000);
    };

    return (
        <div className="space-y-6 mt-6 text-gray-200">
            <Card>
                <div className="flex justify-between items-start mb-3">
                    <h3 className="text-xl font-semibold text-white border-b border-gray-600 pb-2">Hypothetical Title</h3>
                    <Button onClick={() => handleCopy(analysis.title, 'title')} className="bg-gray-700 hover:bg-gray-600 p-2 text-sm">
                        {copied === 'title' ? <CheckIcon /> : <CopyIcon />}
                    </Button>
                </div>
                <p className="text-lg">{analysis.title}</p>
            </Card>

            <Card>
                 <div className="flex justify-between items-start mb-3">
                    <h3 className="text-xl font-semibold text-white border-b border-gray-600 pb-2">Generated Description</h3>
                    <Button onClick={() => handleCopy(analysis.description, 'description')} className="bg-gray-700 hover:bg-gray-600 p-2 text-sm">
                        {copied === 'description' ? <CheckIcon /> : <CopyIcon />}
                    </Button>
                </div>
                <p className="whitespace-pre-wrap leading-relaxed">{analysis.description}</p>
            </Card>

            <Card>
                <div className="flex justify-between items-start mb-3">
                    <h3 className="text-xl font-semibold text-white border-b border-gray-600 pb-2">Suggested Tags</h3>
                    <Button onClick={() => handleCopy(analysis.tags, 'tags')} className="bg-gray-700 hover:bg-gray-600 p-2 text-sm">
                        {copied === 'tags' ? <CheckIcon /> : <CopyIcon />}
                    </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                    {analysis.tags.map((tag, index) => (
                        <span key={index} className="bg-gray-700 text-teal-300 text-sm font-medium px-3 py-1 rounded-full">
                            {tag}
                        </span>
                    ))}
                </div>
            </Card>

            <div className="grid md:grid-cols-2 gap-6">
                <Card>
                    <h3 className="text-xl font-semibold text-white border-b border-green-500 pb-2 mb-3">Strengths</h3>
                    <p className="leading-relaxed">{analysis.strengths}</p>
                </Card>
                <Card>
                    <h3 className="text-xl font-semibold text-white border-b border-red-500 pb-2 mb-3">Weaknesses</h3>
                    <p className="leading-relaxed">{analysis.weaknesses}</p>
                </Card>
            </div>
        </div>
    );
};


const CompetitorAnalysis: React.FC = () => {
    const [videoUrl, setVideoUrl] = useState<string>('');
    const [analysis, setAnalysis] = useState<CompetitorAnalysisResult | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    const handleAnalyze = async () => {
        setError(null);
        setAnalysis(null);

        if (!videoUrl) {
            setError("Please enter a YouTube video URL.");
            return;
        }

        const urlPattern = /^(https?:\/\/)?(www\.)?(youtube\.com\/watch\?v=|youtu\.be\/)[\w-]{11}(\S+)?$/;
        if (!urlPattern.test(videoUrl)) {
            setError("Invalid YouTube URL format. Please use a valid video URL (e.g., youtube.com/watch?v=... or youtu.be/...).");
            return;
        }
        
        setIsLoading(true);

        try {
            const result = await analyzeCompetitorVideo(videoUrl);
            setAnalysis(result);
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : "An unexpected error occurred.";
            setError(errorMessage);
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setVideoUrl(e.target.value);
        if(error) setError(null);
    }

    return (
        <div className="h-full overflow-y-auto p-4 md:p-6 text-gray-200">
            <h1 className="text-3xl font-bold text-white mb-2">Competitor Video Analysis</h1>
            <p className="text-gray-400 mb-6">Enter a competitor's YouTube video URL to get an AI-powered SEO and content analysis.</p>

            <Card>
                <div className="flex flex-col md:flex-row gap-4">
                    <Input
                        type="text"
                        placeholder="e.g., https://www.youtube.com/watch?v=dQw4w9WgXcQ"
                        value={videoUrl}
                        onChange={handleUrlChange}
                        onKeyDown={(e) => e.key === 'Enter' && handleAnalyze()}
                        className="flex-grow bg-gray-700 border-gray-600 text-white"
                        disabled={isLoading}
                    />
                    <Button onClick={handleAnalyze} disabled={isLoading || !videoUrl} className="w-full md:w-auto">
                        {isLoading ? <Spinner /> : 'Analyze Video'}
                    </Button>
                </div>
            </Card>
            
            {error && (
                <div className="mt-6 p-4 bg-red-900/50 border border-red-500 text-red-300 rounded-lg animate-fade-in">
                    <div className="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <div>
                            <p className="font-bold">Analysis Failed</p>
                            <p className="text-sm">{error}</p>
                        </div>
                    </div>
                </div>
            )}

            {isLoading && !analysis && (
                <div className="mt-6 text-center text-gray-400 animate-pulse">
                    <p>AI is analyzing the video... this may take a moment.</p>
                </div>
            )}
            
            {analysis && (
                <div className="animate-fade-in">
                    <AnalysisResult analysis={analysis} />
                </div>
            )}

        </div>
    );
};

export default CompetitorAnalysis;