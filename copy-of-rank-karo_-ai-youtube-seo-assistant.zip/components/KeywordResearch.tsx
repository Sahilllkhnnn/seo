import React, { useState, useMemo, useEffect } from 'react';
import { generateKeywords } from '../services/geminiService';
import type { KeywordResult } from '../types';
import { Card } from './common/Card';
import { Input } from './common/Input';
import { Button } from './common/Button';
import { Spinner } from './common/Spinner';

interface KeywordResearchProps {
    initialTopic?: string;
}

const KeywordResearch: React.FC<KeywordResearchProps> = ({ initialTopic = '' }) => {
    const [topic, setTopic] = useState<string>('');
    const [results, setResults] = useState<KeywordResult[]>([]);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [sortConfig, setSortConfig] = useState<{ key: keyof KeywordResult; direction: 'ascending' | 'descending' } | null>({ key: 'volume', direction: 'descending' });

    useEffect(() => {
        if (initialTopic) {
            setTopic(initialTopic);
        }
    }, [initialTopic]);

    const handleSearch = async () => {
        if (!topic) {
            setError("Please enter a topic.");
            return;
        }
        setIsLoading(true);
        setError(null);
        setResults([]);
        try {
            const keywords = await generateKeywords(topic);
            setResults(keywords);
        } catch (err) {
            setError(err instanceof Error ? err.message : "An unexpected error occurred.");
        } finally {
            setIsLoading(false);
        }
    };
    
    const sortedResults = useMemo(() => {
        let sortableItems = [...results];
        if (sortConfig !== null) {
            sortableItems.sort((a, b) => {
                if (a[sortConfig.key] < b[sortConfig.key]) {
                    return sortConfig.direction === 'ascending' ? -1 : 1;
                }
                if (a[sortConfig.key] > b[sortConfig.key]) {
                    return sortConfig.direction === 'ascending' ? 1 : -1;
                }
                return 0;
            });
        }
        return sortableItems;
    }, [results, sortConfig]);
    
    const requestSort = (key: keyof KeywordResult) => {
        let direction: 'ascending' | 'descending' = 'ascending';
        if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
            direction = 'descending';
        }
        setSortConfig({ key, direction });
    };

    const getCompetitionClass = (competition: 'Low' | 'Medium' | 'High') => {
        switch (competition) {
            case 'Low': return 'bg-green-500/20 text-green-300';
            case 'Medium': return 'bg-yellow-500/20 text-yellow-300';
            case 'High': return 'bg-red-500/20 text-red-300';
            default: return 'bg-gray-500/20 text-gray-300';
        }
    };

    return (
        <div className="h-full overflow-y-auto p-4 md:p-6 text-gray-200">
            <h1 className="text-3xl font-bold text-white mb-2">Keyword Research</h1>
            <p className="text-gray-400 mb-6">Discover the best keywords to target for your next video.</p>

            <Card>
                <div className="flex flex-col md:flex-row gap-4">
                    <Input
                        type="text"
                        placeholder="Enter a topic, e.g., 'beginner drone videography'"
                        value={topic}
                        onChange={(e) => setTopic(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                        className="flex-grow bg-gray-700 border-gray-600 text-white"
                        disabled={isLoading}
                    />
                    <Button onClick={handleSearch} disabled={isLoading || !topic} className="w-full md:w-auto">
                        {isLoading ? <Spinner /> : 'Find Keywords'}
                    </Button>
                </div>
            </Card>

            {error && <p className="mt-4 text-red-400">Error: {error}</p>}

            {isLoading && !results.length && (
                <div className="mt-6 text-center text-gray-400">
                    <p>AI is searching for keywords...</p>
                </div>
            )}

            {results.length > 0 && (
                <Card className="mt-6">
                    <div className="overflow-x-auto">
                        <table className="w-full text-left">
                            <thead>
                                <tr className="border-b border-gray-600">
                                    <th className="p-3 cursor-pointer" onClick={() => requestSort('keyword')}>Keyword</th>
                                    <th className="p-3 cursor-pointer" onClick={() => requestSort('volume')}>Volume</th>
                                    <th className="p-3 cursor-pointer" onClick={() => requestSort('competition')}>Competition</th>
                                </tr>
                            </thead>
                            <tbody>
                                {sortedResults.map((result, index) => (
                                    <tr key={index} className="border-b border-gray-700/50 hover:bg-gray-700/30">
                                        <td className="p-3 font-medium text-white">{result.keyword}</td>
                                        <td className="p-3">{result.volume.toLocaleString()}</td>
                                        <td className="p-3">
                                            <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getCompetitionClass(result.competition)}`}>
                                                {result.competition}
                                            </span>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </Card>
            )}
        </div>
    );
};

export default KeywordResearch;