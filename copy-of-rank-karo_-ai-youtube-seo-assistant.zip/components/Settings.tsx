
import React from 'react';
import { Card } from './common/Card';
import { Input } from './common/Input';
import { Button } from './common/Button';

const Settings: React.FC = () => {
    return (
        <div className="h-full overflow-y-auto p-4 md:p-6 text-gray-200">
            <h1 className="text-3xl font-bold text-white mb-6">Settings</h1>

            <div className="space-y-8 max-w-4xl mx-auto">
                <Card>
                    <h2 className="text-xl font-semibold text-white border-b border-gray-600 pb-3 mb-4">Profile Information</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label className="block text-sm font-medium text-gray-300 mb-2">Name</label>
                            <Input type="text" defaultValue="John Doe" className="w-full bg-gray-700 border-gray-600 text-white" />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-300 mb-2">Email</label>
                            <Input type="email" defaultValue="john.doe@example.com" className="w-full bg-gray-700 border-gray-600 text-white" disabled />
                        </div>
                    </div>
                    <div className="mt-6 text-right">
                        <Button className="bg-teal-500 hover:bg-teal-600">Save Changes</Button>
                    </div>
                </Card>
                
                <Card>
                    <h2 className="text-xl font-semibold text-white border-b border-gray-600 pb-3 mb-4">Subscription Plan</h2>
                    <div className="flex justify-between items-center">
                        <div>
                            <p className="text-lg font-medium">You are on the <span className="text-teal-400 font-bold">Pro Plan</span>.</p>
                            <p className="text-gray-400">Your plan renews on December 31, 2024.</p>
                        </div>
                        <Button className="bg-gray-600 hover:bg-gray-700">Manage Subscription</Button>
                    </div>
                </Card>

                <Card>
                    <h2 className="text-xl font-semibold text-white border-b border-gray-600 pb-3 mb-4">Notifications</h2>
                    <div className="space-y-4">
                        <Toggle label="Email Notifications" description="Receive weekly performance summaries and feature updates." defaultChecked={true} />
                        <Toggle label="In-App Notifications" description="Get notified about new features and important updates within the app." defaultChecked={true} />
                        <Toggle label="Security Alerts" description="Be notified about important security-related events for your account." defaultChecked={true} />
                    </div>
                </Card>
                
                 <Card>
                    <h2 className="text-xl font-semibold text-white border-b border-gray-600 pb-3 mb-4">Delete Account</h2>
                    <div className="flex justify-between items-center">
                        <div>
                            <p className="text-lg font-medium">Permanently delete your account</p>
                            <p className="text-gray-400">This action is irreversible. All your data will be permanently lost.</p>
                        </div>
                        <Button className="bg-red-600 hover:bg-red-700">Delete My Account</Button>
                    </div>
                </Card>

            </div>
        </div>
    );
};

const Toggle: React.FC<{label: string, description: string, defaultChecked?: boolean}> = ({ label, description, defaultChecked }) => (
    <div className="flex items-start justify-between">
        <div>
            <h3 className="font-medium text-white">{label}</h3>
            <p className="text-sm text-gray-400">{description}</p>
        </div>
        <label className="relative inline-flex items-center cursor-pointer">
            <input type="checkbox" value="" className="sr-only peer" defaultChecked={defaultChecked} />
            <div className="w-11 h-6 bg-gray-600 rounded-full peer peer-focus:ring-4 peer-focus:ring-teal-800 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-teal-600"></div>
        </label>
    </div>
);


export default Settings;
