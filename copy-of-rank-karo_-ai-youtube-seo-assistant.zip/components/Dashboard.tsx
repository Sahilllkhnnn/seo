import React, { useState } from 'react';
import type { Page } from '../types';
import { Card } from './common/Card';
import { Button } from './common/Button';
import { Input } from './common/Input';

interface DashboardProps {
    isChannelConnected: boolean;
    onPageChange: (page: Page) => void;
    onQuickStart: (topic: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ isChannelConnected, onPageChange, onQuickStart }) => {
    const [topic, setTopic] = useState('');

    const handleQuickStart = () => {
        if(topic.trim()){
            onQuickStart(topic);
        }
    }

    return (
        <div className="h-full overflow-y-auto p-4 md:p-6 text-gray-200">
            <h1 className="text-3xl font-bold text-white mb-2">Welcome to Rank Karo!</h1>
            <p className="text-gray-400 mb-6">Your AI-powered YouTube SEO co-pilot. Let's get your videos ranking.</p>

            <Card className="mb-6">
                <h2 className="text-xl font-semibold text-white mb-3">Quick Start</h2>
                <p className="text-gray-400 mb-4">Enter a video topic or keywords to begin.</p>
                <div className="flex flex-col md:flex-row gap-4">
                    <Input
                        type="text"
                        placeholder="e.g., 'How to start a successful podcast in 2024'"
                        className="flex-grow bg-gray-700 border-gray-600 text-white"
                        value={topic}
                        onChange={(e) => setTopic(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleQuickStart()}
                    />
                    <Button onClick={handleQuickStart} className="w-full md:w-auto bg-teal-500 hover:bg-teal-600">Generate Ideas</Button>
                </div>
            </Card>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                <FeatureCard
                    title="Keyword Research"
                    description="Find high-volume, low-competition keywords to target."
                    icon={<SearchIcon />}
                    onClick={() => onPageChange('keyword-research')}
                />
                <FeatureCard
                    title="Content Generation"
                    description="Instantly create SEO-optimized titles, descriptions, and tags."
                    icon={<DocumentTextIcon />}
                    onClick={() => onPageChange('content-generator')}
                />
                <FeatureCard
                    title="Competitor Analysis"
                    description="Analyze top-ranking videos to uncover their secrets."
                    icon={<EyeIcon />}
                    onClick={() => onPageChange('competitor-analysis')}
                />
                <AnalyticsCard isConnected={isChannelConnected} onClick={() => onPageChange('analytics')} />
                 <FeatureCard
                    title="Optimization Tips"
                    description="Get actionable, AI-driven advice to improve your video performance."
                    icon={<LightBulbIcon />}
                    onClick={() => onPageChange('settings')}
                />
                 <FeatureCard
                    title="Upgrade to Pro"
                    description="Unlock advanced features and unlimited usage for maximum growth."
                    icon={<SparklesIcon />}
                    onClick={() => onPageChange('upgrade')}
                />
            </div>
        </div>
    );
};

const FeatureCard: React.FC<{title: string; description: string; icon: React.ReactNode; onClick: () => void}> = ({title, description, icon, onClick}) => (
    <Card onClick={onClick} className="flex flex-col hover:bg-gray-700/50 transition-colors cursor-pointer">
        <div className="flex items-center space-x-4 mb-3">
            <div className="bg-gray-900 p-3 rounded-lg">{icon}</div>
            <h3 className="text-lg font-semibold text-white">{title}</h3>
        </div>
        <p className="text-gray-400 flex-grow">{description}</p>
        <div className="text-teal-400 font-semibold mt-4 inline-block">Learn More &rarr;</div>
    </Card>
);

const AnalyticsCard: React.FC<{isConnected: boolean; onClick: () => void}> = ({ isConnected, onClick }) => (
     <Card onClick={onClick} className="flex flex-col hover:bg-gray-700/50 transition-colors cursor-pointer">
        <div className="flex items-center space-x-4 mb-3">
            <div className="bg-gray-900 p-3 rounded-lg"><ChartBarIcon/></div>
            <h3 className="text-lg font-semibold text-white">Analytics Overview</h3>
        </div>
        {isConnected ? (
             <p className="text-gray-400 flex-grow">View your channel's performance, audience retention, and key growth metrics.</p>
        ) : (
            <p className="text-gray-400 flex-grow">Connect your YouTube channel to see your performance dashboard.</p>
        )}
       
        <div className="text-teal-400 font-semibold mt-4 inline-block">{isConnected ? 'View Dashboard' : 'Connect Channel'} &rarr;</div>
    </Card>
)

// Icon components
const SearchIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-teal-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>;
const DocumentTextIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-teal-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>;
const EyeIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-teal-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>;
const ChartBarIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-teal-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>;
const LightBulbIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-teal-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg>;
const SparklesIcon = () => <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-teal-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.293 2.293a1 1 0 010 1.414L13 12l-1.293-1.293a1 1 0 010-1.414L14 7m5 5l2.293 2.293a1 1 0 010 1.414L19 18l-1.293-1.293a1 1 0 010-1.414L20 13M3 14l2.293 2.293a1 1 0 010 1.414L3 20l-1.293-1.293a1 1 0 010-1.414L3 14z" /></svg>;


export default Dashboard;