import React from 'react';
import type { Page } from '../types';
import { PAGES } from '../constants';

interface SidebarProps {
    currentPage: Page;
    onPageChange: (page: Page) => void;
    isChannelConnected: boolean;
}

const NavItem: React.FC<{
    pageId: Page;
    title: string;
    Icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
    isActive: boolean;
    onClick: (pageId: Page) => void;
}> = ({ pageId, title, Icon, isActive, onClick }) => {
    const activeClass = 'bg-teal-500/20 text-teal-300';
    const inactiveClass = 'text-gray-400 hover:bg-gray-700/50 hover:text-white';
    return (
        <li
            onClick={() => onClick(pageId)}
            className={`flex items-center space-x-3 p-3 rounded-lg cursor-pointer transition-all duration-200 ${isActive ? activeClass : inactiveClass}`}
        >
            <Icon className="h-6 w-6" />
            <span className="font-medium">{title}</span>
        </li>
    );
};

const ConnectChannelCard: React.FC<{ onClick: () => void }> = ({ onClick }) => (
    <Card>
        <h3 className="font-bold text-white mb-2">Connect Your Channel</h3>
        <p className="text-sm text-gray-400 mb-4">Unlock powerful analytics and insights by connecting your YouTube channel.</p>
        <Button onClick={onClick} className="w-full bg-blue-600 hover:bg-blue-700">Connect Now</Button>
    </Card>
);

const UpgradeProCard: React.FC<{ onClick: () => void }> = ({ onClick }) => (
    <Card>
        <h3 className="font-bold text-white mb-2">Upgrade to Pro</h3>
        <p className="text-sm text-gray-400 mb-4">Get unlimited access to all features and boost your channel's growth.</p>
        <Button onClick={onClick} className="w-full bg-teal-500 hover:bg-teal-600">Upgrade</Button>
    </Card>
);

export const Sidebar: React.FC<SidebarProps> = ({ currentPage, onPageChange, isChannelConnected }) => {
    return (
        <aside className="w-64 bg-gray-900 p-4 flex flex-col border-r border-gray-700/50">
            <div className="flex items-center space-x-2 mb-8">
                 <svg className="h-8 w-8 text-teal-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                </svg>
                <h1 className="text-2xl font-bold text-white">Rank Karo</h1>
            </div>
            <nav className="flex-1">
                <ul className="space-y-2">
                    {PAGES.filter(p => p.id !== 'upgrade').map(page => (
                        <NavItem
                            key={page.id}
                            pageId={page.id}
                            title={page.title}
                            Icon={page.icon}
                            isActive={currentPage === page.id}
                            onClick={onPageChange}
                        />
                    ))}
                </ul>
            </nav>
            <div className="mt-auto">
                {isChannelConnected ? <UpgradeProCard onClick={() => onPageChange('upgrade')} /> : <ConnectChannelCard onClick={() => onPageChange('analytics')} />}
            </div>
        </aside>
    );
};

// Re-usable components from constants.tsx for sidebar cards
const Card: React.FC<{children: React.ReactNode, className?: string}> = ({ children, className }) => (
    <div className={`bg-gray-800/50 p-4 rounded-lg border border-gray-700/50 ${className}`}>
        {children}
    </div>
);
const Button: React.FC<{children: React.ReactNode, className?: string, onClick?: () => void}> = ({ children, className, onClick }) => (
    <button onClick={onClick} className={`px-4 py-2 rounded-lg font-semibold transition-colors ${className}`}>
        {children}
    </button>
);