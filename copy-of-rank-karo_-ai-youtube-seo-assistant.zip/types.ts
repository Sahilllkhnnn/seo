
export type Page = 'dashboard' | 'keyword-research' | 'content-generator' | 'competitor-analysis' | 'analytics' | 'settings' | 'upgrade';

export interface PageDetail {
    id: Page;
    title: string;
    icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
    component: React.FC<any>;
}

export interface KeywordResult {
    keyword: string;
    volume: number;
    competition: 'Low' | 'Medium' | 'High';
}

export interface GeneratedContent {
    type: 'title' | 'description' | 'tags';
    content: string[];
}

export interface CompetitorAnalysisResult {
    title: string;
    description: string;
    tags: string[];
    strengths: string;
    weaknesses: string;
}

export interface AnalyticsData {
    summary: {
        views: number;
        watchTime: number;
        subscribers: number;
        ctr: number;
    };
    performance: {
        date: string;
        views: number;
    }[];
    topVideos: VideoPerformance[];
}

export interface VideoPerformance {
    rank: number;
    thumbnailUrl: string;
    title: string;
    views: number;
    watchTime: number;
}
