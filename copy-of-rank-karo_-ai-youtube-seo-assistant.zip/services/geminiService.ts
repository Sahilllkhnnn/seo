
import { GoogleGenAI, Type } from "@google/genai";
import type { GenerateContentResponse } from "@google/genai";
import type { KeywordResult, GeneratedContent, CompetitorAnalysisResult } from '../types';

const getAiClient = () => {
    if (!process.env.API_KEY) {
        throw new Error("API key for Gemini is not configured. Please set the API_KEY environment variable.");
    }
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

export const generateKeywords = async (topic: string): Promise<KeywordResult[]> => {
    const ai = getAiClient();
    const prompt = `Generate a list of 15-20 SEO keywords for a YouTube video about "${topic}". The list should include a mix of short-tail, long-tail, and related keywords. For each keyword, provide an estimated monthly search volume (as a number) and competition level ('Low', 'Medium', 'High'). Return the result as a JSON array.`;

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            keyword: { type: Type.STRING },
                            volume: { type: Type.NUMBER },
                            competition: { type: Type.STRING, enum: ['Low', 'Medium', 'High'] },
                        },
                        required: ['keyword', 'volume', 'competition'],
                    }
                }
            }
        });

        const result = JSON.parse(response.text);
        return result as KeywordResult[];
    } catch (error) {
        console.error("Error generating keywords:", error);
        throw new Error("Failed to generate keywords from AI.");
    }
};

export const generateContent = async (type: 'title' | 'description' | 'tags', topic: string, keywords: string[]): Promise<GeneratedContent> => {
    const ai = getAiClient();
    let prompt: string;
    let responseSchema: any;

    const basePrompt = `Based on the topic "${topic}" and keywords like "${keywords.slice(0, 5).join(', ')}", generate content for a YouTube video.`;

    switch (type) {
        case 'title':
            prompt = `${basePrompt} Generate 5 compelling, SEO-optimized YouTube video titles.`;
            responseSchema = { type: Type.ARRAY, items: { type: Type.STRING } };
            break;
        case 'description':
            prompt = `${basePrompt} Generate 3 detailed, keyword-rich YouTube video descriptions. Include a call to action.`;
            responseSchema = { type: Type.ARRAY, items: { type: Type.STRING } };
            break;
        case 'tags':
            prompt = `${basePrompt} Generate a list of 20 relevant YouTube tags.`;
            responseSchema = { type: Type.ARRAY, items: { type: Type.STRING } };
            break;
    }
    
    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: responseSchema,
            },
        });
        const contentArray = JSON.parse(response.text);
        
        return { type, content: contentArray } as GeneratedContent;
    } catch (error) {
        console.error(`Error generating ${type}:`, error);
        throw new Error(`Failed to generate ${type} from AI.`);
    }
};

export const analyzeCompetitorVideo = async (videoUrl: string): Promise<CompetitorAnalysisResult> => {
    const ai = getAiClient();

    const prompt = `
      You are an expert YouTube SEO analyst. A user has provided the following YouTube video URL: ${videoUrl}.
      You do not have access to the internet to watch the video or scrape its content.
  
      Based SOLELY on the information you can infer from a typical YouTube URL structure and your general knowledge of popular video topics, generate a PLAUSIBLE and HYPOTHETICAL SEO analysis for a video that COULD be at this URL.
  
      Your response must follow the provided JSON schema. Do not include any text or explanations outside of the JSON object.
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        title: {
                            type: Type.STRING,
                            description: 'A compelling, SEO-optimized title for a video on a plausible topic. Should be catchy and relevant.',
                        },
                        description: {
                            type: Type.STRING,
                            description: 'A detailed, keyword-rich description, at least 2-3 paragraphs long. It should include placeholder links and a strong call to action.',
                        },
                        tags: {
                            type: Type.ARRAY,
                            items: { type: Type.STRING },
                            description: 'An array of 10-15 relevant, SEO-friendly tags, including a mix of broad and specific terms.',
                        },
                        strengths: {
                            type: Type.STRING,
                            description: "A paragraph summarizing the hypothetical strengths of the video's SEO. Be specific, mentioning title, description, and tags.",
                        },
                        weaknesses: {
                            type: Type.STRING,
                            description: 'A paragraph summarizing hypothetical areas for SEO improvement, providing actionable advice.',
                        },
                    },
                    required: ["title", "description", "tags", "strengths", "weaknesses"],
                },
            },
        });

        const jsonString = response.text;
        const result = JSON.parse(jsonString);

        if (!result.title || !result.description || !result.tags || !result.strengths || !result.weaknesses) {
            throw new Error("AI response is missing required fields. Please try again.");
        }
        
        return result as CompetitorAnalysisResult;

    } catch (error) {
        console.error("Error analyzing competitor video:", error);
        if (error instanceof Error) {
            throw new Error(`Failed to get analysis from AI: ${error.message}`);
        }
        throw new Error("An unknown error occurred while analyzing the video. The AI may be experiencing issues.");
    }
};
