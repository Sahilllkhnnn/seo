import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { PAGES } from './constants';
import { Placeholder } from './components/Placeholder';
import type { Page } from './types';

const App: React.FC = () => {
    const [currentPage, setCurrentPage] = useState<Page>('dashboard');
    const [isChannelConnected, setIsChannelConnected] = useState<boolean>(false);
    const [initialTopic, setInitialTopic] = useState<string>('');

    const handlePageChange = useCallback((page: Page) => {
        setInitialTopic(''); // Reset topic when changing pages manually
        setCurrentPage(page);
    }, []);

    const handleQuickStart = useCallback((topic: string) => {
        setInitialTopic(topic);
        setCurrentPage('keyword-research');
    }, []);

    const handleChannelConnection = useCallback((connected: boolean) => {
        setIsChannelConnected(connected);
        if(connected) {
            setCurrentPage('analytics');
        }
    }, []);

    const pageDetails = PAGES.find(p => p.id === currentPage);
    const PageComponent = pageDetails?.component || Placeholder;

    const pageProps: any = {
        setChannelConnected: handleChannelConnection,
        isChannelConnected: isChannelConnected,
    };

    if (currentPage === 'dashboard') {
        pageProps.onPageChange = handlePageChange;
        pageProps.onQuickStart = handleQuickStart;
    }
    
    if (currentPage === 'keyword-research') {
        pageProps.initialTopic = initialTopic;
    }

    return (
        <div className="flex h-screen bg-gray-900 text-white font-sans">
            <Sidebar currentPage={currentPage} onPageChange={handlePageChange} isChannelConnected={isChannelConnected} />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Header title={pageDetails?.title || 'Rank Karo'} isChannelConnected={isChannelConnected} />
                <main className="flex-1 overflow-y-auto bg-gray-800/50">
                    <PageComponent {...pageProps} />
                </main>
            </div>
        </div>
    );
};

export default App;